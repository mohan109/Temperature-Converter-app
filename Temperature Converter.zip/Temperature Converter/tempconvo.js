const celsius1 = document.getElementById("cels");
const fahrenheit1 = document.getElementById("fahren");

function Fahrenheitconverter(){
    const f = (parseFloat(celsius1.value)*9)/5+32;
    fahrenheit1.value = f.toFixed(2);
}

function Celsiusconverter(){
    const c = ((parseFloat(fahrenheit1.value)-32)*5)/9;
    celsius1.value = c.toFixed(2);
}